Created by Kolachi Studios (kolachi.tech)
Annoucements created using Microsoft Azure Cognitive Services Speech Studio (speech.microsoft.com)

The contents of this zip archive are:
00a-Boarding.mp3
00b-Welcome.mp3
01-Taxi.mp3
02a-PreTakeoff.mp3
02b-Takeoff.mp3
02c-PostTakeoff.mp3
03a-SeatBeltOff.mp3
03b-SeatBeltOn.mp3
04-Descent.mp3
05-Landing.mp3
06-Landed.mp3
07-GoodBye.mp3

Play each of the audio files at appropriate times during the flight for a real-life PIA experience. You can also use the above files with a 3rd party software like LukeAirTool (https://flightsim.to/file/652/lukeairtool), 
FS Cabin Crew (https://fscabincrew.drubware.net/), etc.

If you want .wav files, you can use an online coverter like Cloud Convert (https://cloudconvert.com/)

The following text is for reference only. Feel free to re-use it for translation or creating your own voices.

Welcome:
خواتین و حضرات۔ کپتان اور عملے کی جانب سے ہم آپ کو پاکستان انٹرنیشنل ایئر لائنز کی پرواز میں خوش آمدید کہتے ہیں۔ آپ اپنا سامان اوور ہیڈ بنِ یا اپنے سامنے والی نشست کے نیچے رکھ سکتے ہیں۔ آپ سے گزارش ہے کہ اپنی نشست پر بیٹھ جائیے اور حفاظتی بند باندھ لیجئے۔ ہم جلد ہی اپنی منزل کی جانب روانہ ہو جائیں گے۔ ہمیں امید ہے کہ آپ کا سفر ہمارے ساتھ خوش گوار گزرے گا۔ شکریہ۔
Ladies and gentlemen. On behalf of the captain and crew, we welcome you on this Pakistan International Airlines flight. You can stow your luggage in the overhead bin or under the seat in front of you. You are kindly requsted to remain seated and fasten your seat belt. We will be taking off shortly, and hope you have a pleasant journey with us. Thank You.

Taxi:
خواتین و حضرات۔ اپنے سامنے دی جانے والی اس طیارے کی حفاظتی خصوصیات پر پوری توجہ دیجئے۔
Ladies and gentlemen. We request your full attention to the safety features of this aircraft.

Pre-Takeoff:
[Flight attendants. Prepare for takeoff]

Takeoff:
[Prayer for Journey (Dua-e-Safar)]
شروع اللہ کے نام سے جو بڑا مہربان، نہایت رحم کرنے والا ہے۔ سب تعریف اس ذات کی جس نے اس گاڑی کو ہمارے ماتحت کردیا ہے ، اور پاس اس کو محکوم رکھنے کی طاقت نہیں ہے ، اور ہم اپنے آقا کی طرف ضرور لوٹ آئیں گے۔ بے شک اللہ تعالٰی سچ بولتا ہے۔
In the name of Allah, the most beneficant, the most merciful. Glory to the one who has given this vehicle under our control, and we do not have the power to subjugate it, and to our lord we will surely return. Allah Almighty speaks the truth.

Post-Takeoff:
پاکستان انٹرنیشنل ایئر لائنز کے انتخاب کا شکریہ۔ آپ سے درخواست ہے کہ اپنی نشست پر تشریف رکھیں اور  حفاظتی بند باندھے رکھیں۔ 
Thank you for choosing Pakistan International Airlines. You are kindly requested to remain seated and keep your seat belt securely fastened.

Seat Belt Off:
خواتین و حضرات۔ کپتان نے حفاظتی بند کا نشان بجھا دیا ہے۔ اب آپ کیبن میں گھومنے پھرنے کے لئے آزاد ہیں ، لیکن اگر آپ نشست پر تشریف رکھتے ہیں تو  اپنی حفاظتی بند باندھے رکھیں۔ شکریہ۔
Ladies and gentlemen. The captain has turned off the seat belt sign. You are free to move about in the cabin, but should you remain seated, we request you keep your seat belt securely fastened. Thank you.

Seat Belt On:
خواتین و حضرات۔ کپتان نے حفاظتی بند کا نشان جلا دیا ہے۔ آپ سے گزارش ہے کہ اپنی نشست پر تشریف لے جائیں اور حفاظتی بند باندھ لیں۔ شکریہ۔
Ladies and gentlemen. The captain has turned on the seat belt sign. You are requested to kindly return to your assigned seat and fasten your seat belt. Thank you.

Descent:
خواتین و حضرات۔ ہم نے اپنی منزل مقصود کی جانب پیش قدمی کا آغاز کر دیا ہے اور اب سے کچھ لمحوں بعد مقامی ہوائی اڈے پر اتر جائیں گے۔ شکریہ۔ 
Ladies and gentlemen. We have started our final descent to our destination airport and will be on the ground shortly. Thank you.

Landing:
خواتین و حضرات۔ ہم اپنے منزل کے ہوائی اڈے پر اترنے والے ہیں۔ آپ سے گزارش ہے کہ اپنی نشست پر تشریف رکھیں اور اپنے حفاظتی بند کو مضبوطی سے باندھے رکھیں۔ آپکے تعاون کا شکریہ۔ 
Ladies and gentlemen. We are about to land at our destination airport. You are requested to remain seated and keep your seat belt fastened. Thank you for your cooperation.

Landed:
خواتین و حضرات۔ ہمیں خدمت کا موقع دینے کا شکریہ۔ آپ سے گزارش ہے کہ اس وقت تک اپنی نشست پر تشریف رکھیں جب تک کہ ہم مکمل طور پر رک نہ جاہیں اور کپتان حفاظتی بند کا نشان نہ بجھا دے۔ شکریہ۔ 
Ladies and gentlemen. Thank you for giving us the chance to serve you. You are requested to remain seated until we have come to a complete stop and the captain has turned off the seat belt sign. Thank you.

GoodBye:
[Flight attendants. Prepare doors for arrival] 
خواتین و حضرات۔ ہم آپ کو آپ کی آخری منزل پر خوش آمدید کہتے ہیں۔ یاد رکھیں کہ اوور ہیڈ بن کھولتے وقت محتاط رہیں کیوں کہ پرواز کے دوران سامان منتقل ہوسکتا ہے۔ ہوائی جہاز سے باہر نکلتے وقت ، اپنا تمام دستی سامان ساتھ لے جانا نہ بھولیں۔ ہمارے ساتھ سفر کرنے کا ایک بار پھر شکریہ اور ہم امید کرتے ہیں کہ آپ سے کسی اور پاکستان انٹرنیشنل ایئر لائنز کی پرواز پر دوبارہ ملاقات ہو گی۔ الله نگاہ بان۔
Ladies and gentlemen. We would like to welcome you to your final destination. We ask that you be careful when opening the overhead bins as bags may have shifted during flight. While exiting the aircraft, remember to take all your personal belongings with you. We thank you again for flying with us and hope to see you again on another PIA flight. God bless.
